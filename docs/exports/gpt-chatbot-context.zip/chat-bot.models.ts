export type ChatActorRole = 'guest' | 'public' | 'client' | 'user' | 'staff' | 'admin';

export type ChatIntent =
  | 'greeting'
  | 'faq'
  | 'bot-info'
  | 'help'
  | 'availability-artists'
  | 'availability-next-slot'
  | 'booking'
  | 'status'
  | 'contacts'
  | 'pricing'
  | 'aftercare'
  | 'pre-session'
  | 'tattoo-advice'
  | 'studio-chat'
  | 'clear-chat'
  | 'generic';

export interface ChatMessage {
  from: 'user' | 'bot';
  text: string;
  timestamp: string;
  chips?: string[] | null;
}

export interface ChatPlanContext {
  role?: ChatActorRole;
}

export interface ArtistAvailabilityVm {
  artistId: string;
  artistName: string;
  role: string;
  nextFreeAt: string;
}

export interface NextSlotVm {
  artistId: string;
  artistName: string;
  role: string;
  startAt: string;
}

export interface ChatActionData {
  intent?: ChatIntent;
  artists?: ArtistAvailabilityVm[];
  nextSlot?: NextSlotVm | null;
}

export interface ChatPlanResult {
  message: string;
  chips?: string[];
  suggestedQuestions?: string[];
  actionData?: ChatActionData;
}
