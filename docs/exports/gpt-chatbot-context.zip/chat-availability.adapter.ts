import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { BookingService } from '../bookings/booking.service';
import { StaffMember, StaffService } from '../staff/staff.service';
import { ArtistAvailabilityVm, NextSlotVm } from './chat-bot.models';

interface SlotCandidate {
  artist: StaffMember;
  startAt: string;
}

@Injectable({ providedIn: 'root' })
export class ChatAvailabilityAdapter {
  constructor(
    private staffService: StaffService,
    private bookingService: BookingService
  ) {}

  async getAvailableArtistsSummary(limit = 5): Promise<ArtistAvailabilityVm[]> {
    const candidates = await this.findCandidates(7);
    return candidates
      .slice(0, limit)
      .map((c) => ({
        artistId: String(c.artist.id ?? ''),
        artistName: String(c.artist.name ?? '').trim() || 'Staff',
        role: String(c.artist.role ?? 'staff'),
        nextFreeAt: c.startAt
      }));
  }

  async getNextFreeSlot(): Promise<NextSlotVm | null> {
    const candidates = await this.findCandidates(14);
    const first = candidates[0];
    if (!first) return null;
    return {
      artistId: String(first.artist.id ?? ''),
      artistName: String(first.artist.name ?? '').trim() || 'Staff',
      role: String(first.artist.role ?? 'staff'),
      startAt: first.startAt
    };
  }

  private async findCandidates(dayWindow: number): Promise<SlotCandidate[]> {
    const staff = await firstValueFrom(this.staffService.getAllStaff());
    const active = (staff ?? []).filter((s) => !!s.id && s.isActive !== false);
    if (!active.length) return [];

    const candidates: SlotCandidate[] = [];
    const today = new Date();
    for (const artist of active) {
      const artistId = String(artist.id ?? '').trim();
      if (!artistId) continue;
      let foundForArtist = false;
      for (let offset = 0; offset < dayWindow; offset += 1) {
        const day = new Date(today);
        day.setDate(today.getDate() + offset);
        const ymd = this.toYmd(day);
        // eslint-disable-next-line no-await-in-loop
        const slots = await this.bookingService.getFreeSlotsInDay(artistId, ymd, 60, 60);
        const first = slots?.[0]?.time;
        if (!first) continue;
        candidates.push({ artist, startAt: `${ymd}T${first}:00` });
        foundForArtist = true;
        break;
      }
      if (!foundForArtist) {
        // No-op: if no slot in window do not include artist.
      }
    }

    return candidates.sort((a, b) => a.startAt.localeCompare(b.startAt));
  }

  private toYmd(date: Date): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
}
