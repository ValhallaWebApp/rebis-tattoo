import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, firstValueFrom, Observable } from 'rxjs';
import { environment } from '../../../../environment';
import { ChatAvailabilityAdapter } from './chat-availability.adapter';
import { ChatActorRole, ChatIntent, ChatMessage, ChatPlanContext, ChatPlanResult } from './chat-bot.models';
export type {
  ArtistAvailabilityVm,
  ChatActorRole,
  ChatMessage,
  ChatPlanContext,
  ChatPlanResult,
  NextSlotVm
} from './chat-bot.models';

interface StoredChatState {
  emailToChatId: Record<string, string>;
  chats: Record<string, ChatMessage[]>;
}

@Injectable({ providedIn: 'root' })
export class ChatService {
  private readonly storageKey = 'rebis.chat.front.v2';
  private readonly chatApiBaseUrl = environment.chatApiBaseUrl.replace(/\/+$/, '');
  private readonly subjects = new Map<string, BehaviorSubject<ChatMessage[]>>();
  private state: StoredChatState = this.loadState();
  private readonly studioName = 'Rebis Tattoo';
  private readonly studioPhone = '+39 340 099 8312';
  private readonly studioWhatsapp = 'https://wa.me/393400998312';
  private readonly studioEmail = 'sarapushi@rebistattoo.info';
  private readonly studioAddress = 'Via al Carmine 1A, 07100 Sassari (SS)';
  private readonly studioInstagram = '@rebis_tattoo';

  constructor(
    private availabilityAdapter: ChatAvailabilityAdapter,
    private http: HttpClient
  ) {}

  async createOrReuseChatByEmail(email: string): Promise<string> {
    const key = this.normalizeChatKey(email);
    const existing = this.state.emailToChatId[key];
    if (existing) {
      this.ensureSubject(existing);
      return existing;
    }

    const chatId = this.buildChatId();
    this.state.emailToChatId[key] = chatId;
    this.state.chats[chatId] = [];
    this.persistState();
    this.ensureSubject(chatId);
    return chatId;
  }

  getMessages(chatId: string): Observable<ChatMessage[]> {
    return this.ensureSubject(chatId).asObservable();
  }

  async addMessage(chatId: string, msg: ChatMessage): Promise<void> {
    const subject = this.ensureSubject(chatId);
    const sanitized: ChatMessage = {
      from: msg.from,
      text: (msg.text ?? '').trim(),
      timestamp: msg.timestamp || new Date().toISOString(),
      chips: msg.chips ?? null
    };

    if (!sanitized.text) return;

    const next = [...subject.value, sanitized].slice(-150);
    subject.next(next);
    this.state.chats[chatId] = next;
    this.persistState();
  }

  async clearChat(chatId: string): Promise<void> {
    const subject = this.ensureSubject(chatId);
    subject.next([]);
    this.state.chats[chatId] = [];
    this.persistState();
  }

  async replyWithPlan(
    _chatId: string,
    history: ChatMessage[],
    context: ChatPlanContext = {}
  ): Promise<ChatPlanResult> {
    const role: ChatActorRole = context.role ?? 'guest';
    const lastUser = [...history].reverse().find((m) => m.from === 'user' && m.text.trim().length > 0);

    if (!lastUser) {
      return {
        message: 'Ciao, sono l assistente Rebis. Ti aiuto con consulenze, contatti e WhatsApp dello staff.',
        chips: this.defaultSupportChips(role)
      };
    }

    const text = this.normalize(lastUser.text);
    const intent = this.detectIntent(text);

    if (intent === 'clear-chat') {
      return {
        message: 'Confermo: uso il comando Clear chat per azzerare questa conversazione.',
        chips: ['Clear chat', 'Domande frequenti', 'Prenota consulenza'],
        suggestedQuestions: ['Quanto costa un tatuaggio?', 'Come preparo la seduta?', 'Aftercare base?'],
        actionData: { intent: 'clear-chat' }
      };
    }

    if (this.shouldUseRemoteLlm(intent)) {
      const remoteReply = await this.fetchRemoteReply(lastUser.text, history);
      if (remoteReply) {
        return {
          message: remoteReply,
          chips: this.defaultSupportChips(role),
          suggestedQuestions: ['Quanto costa un tatuaggio?', 'Come preparo la seduta?', 'Aftercare base?']
        };
      }
    }

    if (intent === 'greeting') {
      return {
        message: 'Eccomi. Dimmi pure cosa ti serve: prenotazione, stato richiesta o contatti studio.',
        chips: this.defaultSupportChips(role),
        suggestedQuestions: ['Quanto costa un tatuaggio?', 'Come preparo la seduta?', 'Aftercare base?']
      };
    }

    if (intent === 'bot-info') {
      return {
        message: 'Sono l assistente Rebis: ti aiuto con FAQ veloci, prenotazione consulenza e contatti dello studio.',
        chips: ['Domande frequenti', 'Prenota consulenza', 'Apri WhatsApp studio'],
        suggestedQuestions: ['Quanto costa un tatuaggio?', 'Come preparo la seduta?', 'Come contatto lo studio?']
      };
    }

    if (intent === 'help') {
      return {
        message: 'Posso aiutarti su costi, preparazione seduta, aftercare, contatti e prenotazione consulenza.',
        chips: ['Domande frequenti', 'Prenota consulenza', 'Contatti studio'],
        suggestedQuestions: ['Aftercare base?', 'Quanto dura la seduta?', 'Come contatto lo studio?']
      };
    }

    if (intent === 'faq') {
      return {
        message: 'Domande piu frequenti: costi indicativi, preparazione seduta, durata, guarigione e aftercare.',
        chips: ['Prenota consulenza', 'Apri WhatsApp studio', 'Contatti studio'],
        suggestedQuestions: [
          'Quanto costa un tatuaggio?',
          'Come preparo la seduta?',
          'Quanto dura la seduta?',
          'Aftercare base?',
          'Quando posso espormi al sole?'
        ]
      };
    }

    if (intent === 'availability-artists') {
      try {
        const artists = await this.availabilityAdapter.getAvailableArtistsSummary(5);
        if (!artists.length) {
          return {
            message: 'Nessun artista libero nel breve periodo. Prova a chiedermi la prossima disponibilita.',
            chips: ['Prossima disponibilita', 'Prenota consulenza', 'Apri WhatsApp studio'],
            suggestedQuestions: ['Qual e la prima data utile?', 'Posso prenotare subito?', 'Mi dai i contatti studio?'],
            actionData: { intent: 'availability-artists', artists: [] }
          };
        }

        return {
          message: this.buildArtistsAvailabilityMessage(artists),
          chips: ['Prossima disponibilita', 'Prenota consulenza', 'Apri WhatsApp studio'],
          suggestedQuestions: ['Qual e lo slot piu vicino?', 'Posso prenotare ora?', 'Chi fa piercing?'],
          actionData: { intent: 'availability-artists', artists }
        };
      } catch {
        return {
          message: 'Non riesco a leggere ora la disponibilita live. Puoi contattare lo staff su WhatsApp.',
          chips: ['Apri WhatsApp studio', 'Prenota consulenza', 'Contatti studio']
        };
      }
    }

    if (intent === 'availability-next-slot') {
      try {
        const nextSlot = await this.availabilityAdapter.getNextFreeSlot();
        if (!nextSlot) {
          return {
            message: 'Al momento non trovo slot liberi nel periodo analizzato.',
            chips: ['Artisti liberi', 'Prenota consulenza', 'Apri WhatsApp studio'],
            suggestedQuestions: ['Ci sono artisti liberi?', 'Mi avvisi quando si libera?', 'Contatti studio'],
            actionData: { intent: 'availability-next-slot', nextSlot: null }
          };
        }
        return {
          message: this.buildNextSlotMessage(nextSlot),
          chips: ['Prenota consulenza', 'Artisti liberi', 'Apri WhatsApp studio'],
          suggestedQuestions: ['Mi proponi un alternativa?', 'Chi e disponibile oggi?', 'Come prenoto ora?'],
          actionData: { intent: 'availability-next-slot', nextSlot }
        };
      } catch {
        return {
          message: 'Non riesco a calcolare ora la prossima disponibilita. Contatta lo staff su WhatsApp.',
          chips: ['Apri WhatsApp studio', 'Prenota consulenza', 'Contatti studio']
        };
      }
    }

    if (intent === 'studio-chat') {
      return {
        message: 'Per parlare con lo staff usa WhatsApp: apri la chat e scrivi direttamente al numero dello studio.',
        chips: ['Apri WhatsApp studio', 'Prenota consulenza', 'Contatti studio'],
        suggestedQuestions: ['Mi passi il numero?', 'Chi e libero oggi?', 'Qual e la prossima disponibilita?']
      };
    }

    if (intent === 'booking') {
      return {
        message: 'Per una nuova consulenza puoi prenotare subito. Se vuoi parlare con lo staff, usa WhatsApp studio.',
        chips: ['Prenota consulenza', 'Apri WhatsApp studio', 'Stato prenotazione'],
        suggestedQuestions: ['Chi e libero oggi?', 'Qual e la prima data utile?', 'Quanto dura una seduta?']
      };
    }

    if (intent === 'status') {
      return {
        message: 'Per controllare lo stato della tua richiesta contatta lo staff su WhatsApp.',
        chips: ['Apri WhatsApp studio', 'Prenota consulenza'],
        suggestedQuestions: ['Mi dai i contatti?', 'Qual e la prossima disponibilita?', 'Posso prenotare online?']
      };
    }

    if (intent === 'pricing') {
      return {
        message: 'Per una stima reale servono dettagli progetto e reference. Scrivi allo studio su WhatsApp.',
        chips: ['Apri WhatsApp studio', 'Prenota consulenza'],
        suggestedQuestions: ['Come preparo le reference?', 'Chi e libero oggi?', 'Prenoto una consulenza?']
      };
    }

    if (intent === 'tattoo-advice') {
      return {
        message: 'Per un consiglio preciso indicami zona del corpo, stile desiderato e dimensione. Se vuoi confronto diretto, scrivi allo staff su WhatsApp.',
        chips: ['Apri WhatsApp studio', 'Prenota consulenza', 'Contatti studio'],
        suggestedQuestions: ['Stili disponibili?', 'Quanto tempo ci vuole?', 'Prima disponibilita?']
      };
    }

    if (intent === 'aftercare') {
      return {
        message:
          'Aftercare base: lava delicatamente 2 volte al giorno, asciuga tamponando, applica crema sottile e evita sole, mare e piscina finche non e guarito. Se noti rossore forte o secrezioni, contatta lo studio.',
        chips: ['Apri WhatsApp studio', 'Contatti studio'],
        suggestedQuestions: ['Posso fare sport?', 'Quando espormi al sole?', 'Quando preoccuparmi?']
      };
    }

    if (intent === 'pre-session') {
      return {
        message:
          'Prima della seduta: dormi bene, mangia leggero, idratati, evita alcol nelle 24h precedenti e porta un capo comodo che lasci libera la zona da tatuare.',
        chips: ['Prenota consulenza', 'Apri WhatsApp studio'],
        suggestedQuestions: ['Posso prendere antidolorifici?', 'Quanto dura la seduta?', 'Chi e libero oggi?']
      };
    }

    if (intent === 'contacts') {
      return {
        message: [
          `${this.studioName}`,
          `Telefono: ${this.studioPhone}`,
          `WhatsApp: ${this.studioWhatsapp}`,
          `Email: ${this.studioEmail}`,
          `Indirizzo: ${this.studioAddress}`,
          `Instagram: ${this.studioInstagram}`
        ].join('\n'),
        chips: ['Apri WhatsApp studio', 'Prenota consulenza'],
        suggestedQuestions: ['Quanto costa un tatuaggio?', 'Come preparo la seduta?', 'Come prenoto online?']
      };
    }

    return {
      message: 'Posso aiutarti a prenotare una consulenza, condividere i contatti o aprire WhatsApp con lo staff.',
      chips: this.defaultSupportChips(role),
      suggestedQuestions: ['Quanto costa un tatuaggio?', 'Come preparo la seduta?', 'Aftercare base?']
    };
  }

  private defaultSupportChips(role: ChatActorRole): string[] {
    if (role === 'staff' || role === 'admin') {
      return ['Domande frequenti', 'Apri WhatsApp studio', 'Contatti studio'];
    }
    return ['Domande frequenti', 'Prenota consulenza', 'Apri WhatsApp studio'];
  }

  private detectIntent(text: string): ChatIntent {
    if (!text) return 'generic';
    if (this.matchesAny(text, ['ciao', 'salve', 'buongiorno', 'buonasera', 'hey'])) return 'greeting';
    if (this.matchesAny(text, ['clear chat', 'pulisci chat', 'azzera chat', 'cancella chat'])) return 'clear-chat';
    if (this.matchesAny(text, ['faq', 'domande frequenti', 'domande comuni', 'domande'])) return 'faq';
    if (this.matchesAny(text, ['chi sei', 'chisei', 'cosa fai', 'cosafai', 'a che servi', 'acheservi'])) return 'bot-info';
    if (this.matchesAny(text, ['aiuto', 'help', 'mi aiuti', 'miaiuti'])) return 'help';

    if (this.matchesAny(text, ['artisti liberi', 'chi e libero', 'chi è libero', 'disponibilita artisti', 'disponibilità artisti'])) {
      return 'availability-artists';
    }
    if (this.matchesAny(text, ['prossima disponibilita', 'prossima disponibilità', 'prima disponibilita', 'prima disponibilità', 'primo slot libero'])) {
      return 'availability-next-slot';
    }

    const asksStatus = this.matchesAny(text, ['stato', 'aggiornamento', 'conferm', 'avanzamento']);
    const contextBooking = this.matchesAny(text, ['prenot', 'booking', 'session', 'sedut', 'richiesta', 'progetto']);
    if (asksStatus && contextBooking) return 'status';

    if (this.matchesAny(text, ['operatore', 'umano', 'chat', 'assistenza', 'supporto', 'studio'])) return 'studio-chat';
    if (this.matchesAny(text, ['prezzo', 'costo', 'preventivo', 'quanto'])) return 'pricing';
    if (this.matchesAny(text, ['cura', 'guarig', 'aftercare', 'cicatrizz', 'crema'])) return 'aftercare';
    if (this.matchesAny(text, ['prima della seduta', 'prima seduta', 'prepar', 'come mi preparo', 'cosa porto'])) return 'pre-session';
    if (this.matchesAny(text, ['consiglio', 'stile', 'idea', 'soggetto', 'dimensione', 'posizione', 'zona'])) return 'tattoo-advice';
    if (this.matchesAny(text, ['orari', 'orario', 'telefono', 'email', 'indirizzo', 'instagram', 'contatti', 'dove'])) return 'contacts';
    if (this.matchesAny(text, ['prenot', 'consulenza', 'appuntamento', 'session', 'sedut'])) return 'booking';

    return 'generic';
  }

  private matchesAny(text: string, terms: readonly string[]): boolean {
    const normalizedText = this.normalizeForMatching(text);
    return terms.some((term) => {
      const normalizedTerm = this.normalizeForMatching(term);
      return text.includes(term) || normalizedText.includes(normalizedTerm);
    });
  }

  private normalize(value: string): string {
    return String(value ?? '').toLowerCase().trim();
  }

  private normalizeForMatching(value: string): string {
    return String(value ?? '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]/g, '');
  }

  private ensureSubject(chatId: string): BehaviorSubject<ChatMessage[]> {
    const existing = this.subjects.get(chatId);
    if (existing) return existing;

    const list = this.state.chats[chatId] ?? [];
    this.state.chats[chatId] = list;
    const subject = new BehaviorSubject<ChatMessage[]>(list);
    this.subjects.set(chatId, subject);
    this.persistState();
    return subject;
  }

  private normalizeChatKey(email: string): string {
    return (email || 'guest')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9@._-]/g, '');
  }

  private buildChatId(): string {
    const rand = Math.random().toString(36).slice(2, 10);
    return `chat_${Date.now()}_${rand}`;
  }

  private buildArtistsAvailabilityMessage(artists: { artistName: string; nextFreeAt: string }[]): string {
    const total = artists.length;
    const preview = artists
      .slice(0, 2)
      .map((a) => `${a.artistName} (${this.formatShortDateTime(a.nextFreeAt)})`)
      .join(', ');
    return `Trovati ${total} artisti disponibili. Prime disponibilita: ${preview}.`;
  }

  private buildNextSlotMessage(nextSlot: { artistName: string; startAt: string }): string {
    return `Prossimo slot libero: ${nextSlot.artistName} il ${this.formatShortDateTime(nextSlot.startAt)}.`;
  }

  private shouldUseRemoteLlm(intent: ChatIntent): boolean {
    return !['clear-chat', 'availability-artists', 'availability-next-slot'].includes(intent);
  }

  private async fetchRemoteReply(lastUserMessage: string, history: ChatMessage[]): Promise<string | null> {
    if (!this.chatApiBaseUrl) return null;

    const payload = {
      message: String(lastUserMessage ?? '').trim(),
      history: history
        .filter((m) => (m.from === 'user' || m.from === 'bot') && String(m.text ?? '').trim().length > 0)
        .slice(-20)
        .map((m) => ({
          role: m.from === 'bot' ? 'assistant' : 'user',
          content: String(m.text ?? '').trim()
        }))
    };

    try {
      const res = await firstValueFrom(
        this.http.post<{ ok?: boolean; reply?: string }>(`${this.chatApiBaseUrl}/complete`, payload)
      );
      const reply = String(res?.reply ?? '').trim();
      return reply.length ? reply : null;
    } catch {
      return null;
    }
  }

  private formatShortDateTime(value: string): string {
    const date = new Date(String(value ?? '').trim());
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  private loadState(): StoredChatState {
    try {
      const raw = this.safeStorageGet(this.storageKey);
      if (!raw) {
        return { emailToChatId: {}, chats: {} };
      }

      const parsed = JSON.parse(raw) as Partial<StoredChatState>;
      return {
        emailToChatId: parsed.emailToChatId ?? {},
        chats: parsed.chats ?? {}
      };
    } catch {
      return { emailToChatId: {}, chats: {} };
    }
  }

  private persistState(): void {
    this.safeStorageSet(this.storageKey, JSON.stringify(this.state));
  }

  private safeStorageGet(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  private safeStorageSet(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch {
      // Ignore write errors (private mode / quota).
    }
  }
}
