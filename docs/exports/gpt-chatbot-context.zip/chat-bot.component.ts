import {
  Component, ViewChild, ElementRef, AfterViewChecked
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { MaterialModule } from '../../../core/modules/material.module';
import { ArtistAvailabilityVm, ChatMessage, ChatService, NextSlotVm } from '../../../core/services/chatBot/chat-bot.service';
import { AuthService } from '../../../core/services/auth/auth.service';
import { FastBookingStore } from '../../../features/public/fast-booking/state/fast-booking-store.service';

@Component({
  selector: 'app-chat-bot',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MaterialModule],
  templateUrl: './chat-bot.component.html',
  styleUrls: ['./chat-bot.component.scss']
})
export class ChatBotComponent implements AfterViewChecked {
  private readonly guestChatIdentityKey = 'rebis.chat.guest.identity';
  private readonly studioWhatsappNumber = '393400998312';
  private lastSubmit: { text: string; at: number } | null = null;

  messages: Array<{
    text: string;
    from: 'user' | 'bot';
    chips?: string[] | null;
    suggestedQuestions?: string[] | null;
    artists?: ArtistAvailabilityVm[] | null;
    nextSlot?: NextSlotVm | null;
  }> = [];
  inputCtrl = new FormControl<string>('', { nonNullable: true });
  typing = false;
  isUserAtBottom = true;
  loadingLabel = 'Sto preparando la risposta...';

  chatId: string | null = null;
  userId: string | null = null;
  userName?: string;

  @ViewChild('scrollContainer') scrollContainer!: ElementRef;
  @ViewChild('bottomAnchor') bottomAnchor!: ElementRef;

  constructor(
    private chatService: ChatService,
    private auth: AuthService,
    private router: Router,
    private fastBookingStore: FastBookingStore
  ) {
    this.startConversation();
  }

  ngAfterViewChecked(): void {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    this.bottomAnchor?.nativeElement?.scrollIntoView({ behavior: 'smooth' });
  }

  onScroll(): void {
    const el = this.scrollContainer.nativeElement;
    const threshold = 150;
    this.isUserAtBottom = (el.scrollTop + el.clientHeight) >= (el.scrollHeight - threshold);
  }

  trackByIndex = (i: number) => i;

  addUserMessage(text: string): void {
    this.messages.push({ text, from: 'user' });
    this.saveMessage('user', text);
  }

  addBotMessage(text: string, chips?: string[] | null): void {
    this.messages.push({
      text,
      from: 'bot',
      chips: chips?.length ? chips : null,
      suggestedQuestions: null,
      artists: null,
      nextSlot: null
    });
    this.saveMessage('bot', text, chips || undefined);
  }

  saveMessage(from: 'user' | 'bot', text: string, chips?: string[]): void {
    if (!this.chatId) return;

    const msg: ChatMessage = {
      from,
      text,
      timestamp: new Date().toISOString(),
      chips: chips ?? null
    };

    void this.chatService.addMessage(this.chatId, msg).catch((err) => console.error('saveMessage ERROR', err));
  }

  private listenToChat(chatId: string): void {
    this.chatService.getMessages(chatId).subscribe((list) => {
      this.messages = list.map((m) => ({
        text: m.text,
        from: m.from,
        chips: m.chips || null,
        suggestedQuestions: null,
        artists: null,
        nextSlot: null
      }));
      this.scrollToBottom();

      if (this.messages.length === 0) {
        this.addBotMessage(
          'Ciao, sono l assistente Rebis. Ti aiuto con consulenze, contatti e WhatsApp dello staff.',
          this.defaultChipsForCurrentRole()
        );
      }
    });
  }

  startConversation(): void {
    const user = this.auth.userSig();

    if (user) {
      this.userId = user.uid;
      this.userName = user.name || undefined;
      const identity = user.email || user.uid;

      void this.chatService.createOrReuseChatByEmail(identity).then((chatId) => {
        this.chatId = chatId;
        this.listenToChat(chatId);
      });

      return;
    }

    const guestIdentity = this.getGuestIdentity();
    this.userId = null;
    this.userName = undefined;

    void this.chatService.createOrReuseChatByEmail(guestIdentity).then((chatId) => {
      this.chatId = chatId;
      this.listenToChat(chatId);
    });
  }

  async sendMessage(): Promise<void> {
    const userText = this.inputCtrl.value.trim();
    if (!userText || !this.chatId || this.typing) return;
    const now = Date.now();
    if (this.lastSubmit && this.lastSubmit.text === userText && now - this.lastSubmit.at < 1200) {
      return;
    }
    this.lastSubmit = { text: userText, at: now };

    this.addUserMessage(userText);
    this.inputCtrl.setValue('');
    this.typing = true;
    await this.flushUi();

    try {
      const history: ChatMessage[] = this.messages.map((m) => ({
        from: m.from,
        text: m.text,
        timestamp: new Date().toISOString(),
        chips: m.chips || undefined
      }));

      const role = this.auth.userSig()?.role ?? 'guest';
      const plan = await this.chatService.replyWithPlan(this.chatId, history, { role });

      if (plan.actionData?.intent === 'clear-chat') {
        await this.chatService.clearChat(this.chatId);
        this.messages = [];
      }

      this.messages.push({
        text: plan.message,
        from: 'bot',
        chips: plan.chips?.length ? plan.chips : null,
        suggestedQuestions: plan.suggestedQuestions?.length ? plan.suggestedQuestions : null,
        artists: plan.actionData?.artists ?? null,
        nextSlot: plan.actionData?.nextSlot ?? null
      });
      this.saveMessage('bot', plan.message, plan.chips || undefined);
    } catch (err) {
      console.error('Errore chatbot:', err);
      this.addBotMessage('Errore durante la risposta. Riprova tra qualche secondo.');
    } finally {
      this.typing = false;
    }
  }

  onChipClick(label: string): void {
    if (this.typing) return;

    if (label === 'Clear chat') {
      void this.handleClearChat();
      return;
    }

    if (label === 'Apri chat studio' || label === 'Apri WhatsApp studio') {
      this.openStudioWhatsApp();
      return;
    }

    if (label === 'Accedi' || label === 'Registrati') {
      this.openLoginForStudioChat();
      return;
    }

    if (label === 'Prenota consulenza' || label === 'Apri consulenza') {
      this.openFastBookingPrefilledFromChat();
      return;
    }

    if (label === 'Contatti studio' || label === 'Orari studio') {
      void this.router.navigate(['/contatti']);
      return;
    }

    if (label === 'Vai al profilo' || label === 'Stato prenotazione') {
      this.openStudioWhatsApp();
      return;
    }

    this.inputCtrl.setValue(label);
    void this.sendMessage();
  }

  onSuggestedQuestionClick(question: string): void {
    const text = String(question ?? '').trim();
    if (!text || this.typing) return;
    this.inputCtrl.setValue(text);
    void this.sendMessage();
  }

  private getGuestIdentity(): string {
    const existing = this.safeStorageGet(this.guestChatIdentityKey);
    if (existing) return existing;

    const generated = `guest-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    this.safeStorageSet(this.guestChatIdentityKey, generated);
    return generated;
  }

  private safeStorageGet(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  private safeStorageSet(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch {
      // Ignore storage errors.
    }
  }

  private defaultChipsForCurrentRole(): string[] {
    return ['Domande frequenti', 'Prenota consulenza', 'Clear chat', 'Apri WhatsApp studio'];
  }

  private openStudioWhatsApp(): void {
    const latestUserMessage = this.latestUserMessage();
    const text = latestUserMessage
      ? `Ciao Rebis, arrivo dal chatbot. Richiesta: ${latestUserMessage}`
      : 'Ciao Rebis, arrivo dal chatbot e vorrei parlare con lo staff.';
    const url = `https://wa.me/${this.studioWhatsappNumber}?text=${encodeURIComponent(text.slice(0, 500))}`;

    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      void this.router.navigate(['/contatti']);
    }
  }

  private openLoginForStudioChat(): void {
    this.safeStorageSet('pre-log', '/contatti');
    void this.router.navigate(['/login']);
  }

  private latestUserMessage(): string {
    const item = [...this.messages].reverse().find((m) => m.from === 'user' && m.text.trim().length > 0);
    return item?.text?.trim() ?? '';
  }

  private latestBotMessage(): {
    text: string;
    from: 'user' | 'bot';
    chips?: string[] | null;
    suggestedQuestions?: string[] | null;
    artists?: ArtistAvailabilityVm[] | null;
    nextSlot?: NextSlotVm | null;
  } | null {
    return [...this.messages].reverse().find((m) => m.from === 'bot') ?? null;
  }

  private latestAvailabilityBotMessage(): {
    text: string;
    from: 'user' | 'bot';
    chips?: string[] | null;
    suggestedQuestions?: string[] | null;
    artists?: ArtistAvailabilityVm[] | null;
    nextSlot?: NextSlotVm | null;
  } | null {
    return (
      [...this.messages]
        .reverse()
        .find(
          (m) =>
            m.from === 'bot' &&
            ((m.nextSlot && String(m.nextSlot.artistId ?? '').trim().length > 0) ||
              (Array.isArray(m.artists) &&
                m.artists.some((a) => String(a.artistId ?? '').trim().length > 0)))
        ) ?? null
    );
  }

  private openFastBookingPrefilledFromChat(): void {
    const bot = this.latestAvailabilityBotMessage() ?? this.latestBotMessage();
    const latestUser = this.latestUserMessage();

    const candidateArtist = bot?.nextSlot?.artistId || bot?.artists?.[0]?.artistId || null;
    const candidateDateTime = bot?.nextSlot?.startAt || bot?.artists?.[0]?.nextFreeAt || null;
    const description = latestUser ? `Richiesta da chatbot: ${latestUser}` : 'Richiesta avviata da chatbot.';

    this.fastBookingStore.seedFromChatbot({
      artistId: candidateArtist,
      date: candidateDateTime,
      description
    });

    void this.router.navigate(['/fast-booking']);
  }

  formatSlot(value: string | null | undefined): string {
    const raw = String(value ?? '').trim();
    if (!raw) return '-';
    const date = new Date(raw);
    if (Number.isNaN(date.getTime())) return raw;
    return date.toLocaleString('it-IT', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  async handleClearChat(): Promise<void> {
    if (!this.chatId) return;
    await this.chatService.clearChat(this.chatId);
    this.messages = [];
    this.addBotMessage(
      'Chat pulita. Vuoi FAQ veloci, prenotare una consulenza o aprire WhatsApp?',
      this.defaultChipsForCurrentRole()
    );
  }

  private async flushUi(): Promise<void> {
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
    if (typeof requestAnimationFrame === 'function') {
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    }
  }
}


