const isLocalHost = ['localhost', '127.0.0.1'].includes(window.location.hostname);
const paymentApiBaseUrl = isLocalHost
  ? 'http://localhost:3000/api/payments'
  : 'https://payment-service.valhallawebapp.workers.dev/api/payments';

window.__APP_CONFIG__ = {
  paymentApiBaseUrl,
  stripePublishableKey: 'pk_test_51QNHjmHTS8uBqIoqBo51zWatjkDbUcP3SECoQb1Y859MfKtk6WbIfNRvpDJfdBUJP58OOPDPaQibnTjRbd6vgdWx00Mh7pSPeZ',
  allowStripeTestKeyInProduction: true,
  firebaseConfig: {
    apiKey: 'AIzaSyDFOFTJ9p60YeoVdLGo8ZfuaOOaUpgAP5E',
    authDomain: 'rebis-tattoo-55816.firebaseapp.com',
    databaseURL: 'https://rebis-tattoo-55816-default-rtdb.europe-west1.firebasedatabase.app/',
    projectId: 'rebis-tattoo-55816',
    storageBucket: 'rebis-tattoo-55816.firebasestorage.app',
    messagingSenderId: '70352364616',
    appId: '1:70352364616:web:24a6df01d24f6b4947647d',
    measurementId: 'G-1HW9SPJ1CN'
  }
};


