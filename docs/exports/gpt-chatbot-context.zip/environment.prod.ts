import { AppEnvironment } from './environment.model';
import { withRuntimeConfig } from './runtime-config';

const baseEnvironment: AppEnvironment = {
  production: true,
  environmentName: 'production',
  paymentApiBaseUrl: 'https://payment-service.valhallawebapp.workers.dev/api/payments',
  chatApiBaseUrl: 'https://chat-service.valhallawebapp.workers.dev/api/chat',
  firebaseConfig: {
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
    measurementId: ''
  },
  stripePublishableKey: ''
};

export const environment: AppEnvironment = withRuntimeConfig(baseEnvironment);
