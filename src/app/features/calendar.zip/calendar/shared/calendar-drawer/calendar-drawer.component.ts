import { Component } from '@angular/core';

@Component({
  selector: 'app-calendar-drawer',
  standalone: true,
  imports: [],
  templateUrl: './calendar-drawer.component.html',
  styleUrl: './calendar-drawer.component.scss'
})
export class CalendarDrawerComponent {

}
