import { Component } from '@angular/core';

@Component({
  selector: 'app-calendar-slot',
  standalone: true,
  imports: [],
  templateUrl: './calendar-slot.component.html',
  styleUrl: './calendar-slot.component.scss'
})
export class CalendarSlotComponent {

}
