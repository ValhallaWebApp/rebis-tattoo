import { Component } from '@angular/core';

@Component({
  selector: 'app-client-detail',
  standalone:true,
  imports: [],
  templateUrl: './client-detail.component.html',
  styleUrl: './client-detail.component.scss'
})
export class ClientDetailComponent {

}
