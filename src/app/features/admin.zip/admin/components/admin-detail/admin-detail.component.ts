import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-detail',
  imports: [],
  templateUrl: './admin-detail.component.html',
  styleUrl: './admin-detail.component.scss'
})
export class AdminDetailComponent {

}
