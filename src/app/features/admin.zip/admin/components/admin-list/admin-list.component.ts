import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-list',
  imports: [],
  templateUrl: './admin-list.component.html',
  styleUrl: './admin-list.component.scss'
})
export class AdminListComponent {

}
